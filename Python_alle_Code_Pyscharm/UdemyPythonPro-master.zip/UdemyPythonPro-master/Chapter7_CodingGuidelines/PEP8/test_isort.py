from __future__ import absolute_import

import imp
import os
import sys
from os import abort
from os import access
from os import pardir
from os import path

import numpy as np

from my_lib import A


print("Hey")
print("yo")
