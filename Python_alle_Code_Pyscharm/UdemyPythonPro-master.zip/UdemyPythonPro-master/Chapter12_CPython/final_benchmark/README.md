# Execute

```bash
pytest --benchmark-columns=min,max,mean,stddev --benchmark-sort=mean benchmark.py
```
