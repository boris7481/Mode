# Fortgeschrittene Python Programmierung

Dies ist der Code zu meinem Udemy Kurs:
*Fortgeschrittene Python Programmierung* von Jan Schaffranek.

## Rabatt-Code

Im Folgenden habe ich einen Link zum aktuellen Rabatt Code hinterlegt. Den Code könnt ihr auch an eure Freunde schicken, damit sie sich einen meiner Kurse kaufen können. Bei einem Kauf über meine Rabattcodes erhalte ich 95% der Einnahmen und somit könnt Ihr mich besser unterstützen.

Link zu der Liste der Rabatt Codes: [Link](https://github.com/franneck94/YoutubeVideos/blob/master/README.md)
