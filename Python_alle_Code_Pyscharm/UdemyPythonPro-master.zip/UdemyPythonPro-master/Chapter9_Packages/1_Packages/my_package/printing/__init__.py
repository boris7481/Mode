def hello_world() -> None:
    print("Hello World!")
