# FastVector

This is a simple example for a python package.
