# API

## Vector Class

::: fastvector.vector
